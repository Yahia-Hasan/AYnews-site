This project is the final preoject (news)Using only  Html & css & js
named(AY News) 
made by 
1-Yahia Hassan Ewas (yehea2002@gmail.com)
2-Ayat Ali Hassan   (ayatali1661@gmail.com)

the first bage is (index.html) and open server using vscode .
